"""
Centralized vehicle state for CopterSonde GCS.

A single ``VehicleState`` instance holds all telemetry fields parsed from
MAVLink messages.  The MAVLink client (or sim generator) updates this
object; UI screens read from it on the main thread.

Thread-safety note: individual field writes from the IO thread and reads
from the UI thread are safe for Python built-in types (GIL guarantees
atomic reference assignment).  The ``snapshot()`` method returns a plain
dict for convenience.
"""

import math
import time
from collections import deque  # deque with maxlen gives O(1) append + auto-eviction
from dataclasses import dataclass, field


# --- ADS-B target tracking ---
@dataclass
class ADSBTarget:
    icao: int = 0
    callsign: str = ""
    lat: float = 0.0
    lon: float = 0.0
    alt_m: float = 0.0
    heading: float = 0.0
    speed_ms: float = 0.0
    last_seen: float = 0.0


# --- Autopilot status messages (STATUSTEXT) ---
@dataclass
class StatusMessage:
    severity: int = 0
    severity_name: str = ""
    text: str = ""
    timestamp: float = 0.0


class VehicleState:
    """Mutable container for all vehicle telemetry."""

    def __init__(self):
        self.reset()

    def reset(self):
        """Clear all fields to defaults."""
        # GPS
        self.lat = 0.0
        self.lon = 0.0
        self.alt_amsl = 0.0
        self.alt_rel = 0.0
        self.fix_type = 0
        self.satellites = 0
        self.hdop = 99.99  # sentinel: worst-case until real fix arrives

        # Attitude (radians)
        self.roll = 0.0
        self.pitch = 0.0
        self.yaw = 0.0

        # Attitude rates (rad/s) from ATTITUDE (msg 30)
        self.rollspeed = 0.0
        self.pitchspeed = 0.0
        self.yawspeed = 0.0

        # Heading (degrees)
        self.heading_deg = 0.0

        # Speed
        self.groundspeed = 0.0
        self.airspeed = 0.0
        self.vx = 0.0  # cm/s north
        self.vy = 0.0  # cm/s east
        self.vz = 0.0  # cm/s down (positive = descending)
        # Velocity from LOCAL_POSITION_NED (msg 32), m/s NED — the raw
        # file's Velocity columns and ascent detection use these, not the
        # cm/s values above.
        self.vx_ned = 0.0  # m/s north
        self.vy_ned = 0.0  # m/s east
        self.vz_ned = 0.0  # m/s down (positive = descending)

        # Battery
        self.voltage = 0.0
        self.current = 0.0  # milliamps
        self.battery_pct = 0

        # Radio
        self.rssi_percent = 0

        # System
        self.armed = False
        self.flight_mode = "---"
        self.custom_mode = 0  # raw HEARTBEAT.custom_mode int (flight_mode is the decoded name)
        self.system_status = 0
        self.last_heartbeat = 0.0

        # Sensors (CASS) — populated from custom CASS_SENSOR_RAW (msg 227)
        self.temperature_sensors: list[float] = []  # individual iMet probes (K)
        self.humidity_sensors: list[float] = []      # individual HYT probes (%)
        self.mean_temp = float("nan")  # Kelvin (NaN = no sensor data)
        self.mean_rh = float("nan")    # percent (NaN = no sensor data)
        self.pressure = 0.0        # hPa

        # Wind (computed from pitch via SWX quadratic regression, not measured)
        self.wind_speed = 0.0      # m/s
        self.wind_direction = 0.0  # radians (CopterSonde yaw; it points into wind)
        self.vertical_wind = 0.0   # m/s (positive = updraft)

        # ADS-B
        self.adsb_targets: dict[int, ADSBTarget] = {}

        # Status messages
        self.status_messages: list[StatusMessage] = []
        # Total messages ever appended this session — monotonic, unlike
        # len(status_messages) which saturates at the 200-entry cap.  The
        # Flight screen keys its display-cache invalidation on this counter.
        self.status_messages_total = 0

        # Throttle
        self.throttle = 0

        # Timestamps
        self.time_since_boot = 0
        self.utc_time = None

        # Servo / RPM (for wind estimation)
        self.servo_raw: list[int] = [0] * 8

        # History buffers for time-series and profile plots.
        # Unbounded deques — data accumulates for the entire flight and is
        # cleared automatically on each arm event (disarmed -> armed
        # transition) so every flight starts with a clean slate.  Memory is
        # modest (~7 MB per hour at 10 Hz) and the UI is protected by
        # per-screen downsampling, throttling, and list-snapshot copies.
        self._history_keys = [
            "h_time", "h_lat", "h_lon", "h_alt_rel", "h_alt_amsl",
            "h_temperature", "h_humidity", "h_dew_temp",
            "h_wind_speed", "h_wind_dir", "h_vert_wind",
            "h_temp_sensors", "h_rh_sensors", "h_vz",
        ]
        for k in self._history_keys:
            setattr(self, k, deque())

        # ALM plot buffers (SoW 205195 #19): one entry per completed 5 m
        # altitude bin of the current ascent.  Cleared when a new ascent
        # begins, so after an ascent ends the graphs keep showing it until
        # the next one starts (matching the ALM display convention).
        # Written from the MAVLink IO / sim thread, read from the UI thread;
        # clear_alm() swaps in fresh lists rather than mutating in place so
        # a concurrent reader only ever sees a whole old or whole new list.
        self._alm_keys = ["alm_tss", "alm_alt", "alm_temp", "alm_rh",
                          "alm_dew", "alm_wspd"]
        self.clear_alm()

    def clear_alm(self):
        """Reset the ALM plot buffers (a new ascent has begun)."""
        for k in self._alm_keys:
            setattr(self, k, [])
        self._alm_t0 = None

    def append_alm_bin(self, t, alt, temp_c, rh, dew_c, wspd):
        """Append one completed ALM bin for the plots.

        ``t`` is the bin's UNIX time; the stored x value is time since the
        ascent's first bin, mirroring the ALM file's Time Since Start
        column (first entry is 0).
        """
        if self._alm_t0 is None:
            self._alm_t0 = t
        self.alm_tss.append(t - self._alm_t0)
        self.alm_alt.append(alt)
        self.alm_temp.append(temp_c)
        self.alm_rh.append(rh)
        self.alm_dew.append(dew_c)
        self.alm_wspd.append(wspd)

    def set_armed(self, armed: bool):
        """Set armed state; auto-clears history on disarmed -> armed transition."""
        if armed and not self.armed:
            self.clear_history()
        self.armed = armed

    def clear_history(self):
        """Clear only history arrays, keep current-value fields."""
        for k in self._history_keys:
            setattr(self, k, deque())
        self.clear_alm()

    def heartbeat_age(self):
        if self.last_heartbeat == 0.0:
            return float("inf")
        return time.monotonic() - self.last_heartbeat

    def is_healthy(self):
        return self.heartbeat_age() < 3.0

    def dew_point(self, temp_c, rh):
        """Magnus formula dew-point approximation.

        Uses the August-Roche-Magnus coefficients (a=17.625, b=243.04 C)
        which are accurate to within ~0.4 C for -40..60 C.
        """
        if rh <= 0 or temp_c < -50:
            return temp_c - 10.0  # degenerate input; return a safe fallback
        a, b = 17.625, 243.04  # Magnus coefficients (dimensionless / deg C)
        # alpha = ln(e/e_s0) where e is actual vapour pressure
        alpha = math.log(rh / 100.0) + a * temp_c / (b + temp_c)
        return (b * alpha) / (a - alpha)

    def append_history(self, data: dict):
        """Append one sample to the rolling history buffers.

        Uses deque(maxlen) so eviction of old samples is O(1).
        """
        self.h_time.append(data.get("time_since_boot", 0))
        self.h_lat.append(data.get("lat", 0))
        self.h_lon.append(data.get("lon", 0))
        self.h_alt_rel.append(data.get("alt_rel", 0))
        self.h_alt_amsl.append(data.get("alt_amsl", 0))
        self.h_temperature.append(data.get("temperature", 0))
        self.h_humidity.append(data.get("humidity", 0))
        self.h_dew_temp.append(data.get("dew_temp", 0))
        self.h_wind_speed.append(data.get("wind_speed", 0))
        self.h_wind_dir.append(data.get("wind_dir", 0))
        self.h_vert_wind.append(data.get("vert_wind", 0))
        self.h_temp_sensors.append(data.get("temp_sensors", []))
        self.h_rh_sensors.append(data.get("rh_sensors", []))
        self.h_vz.append(data.get("vz", 0))

    def snapshot(self) -> dict:
        """Return a plain-dict snapshot of the most commonly needed fields.

        A shallow copy keeps the UI thread from seeing partially-written
        compound objects. Safe to call from any thread (GIL protects each
        individual attribute read).
        """
        return {
            "lat": self.lat, "lon": self.lon,
            "alt_amsl": self.alt_amsl, "alt_rel": self.alt_rel,
            "fix_type": self.fix_type, "satellites": self.satellites,
            "hdop": self.hdop,
            "roll": self.roll, "pitch": self.pitch, "yaw": self.yaw,
            "heading_deg": self.heading_deg,
            "groundspeed": self.groundspeed, "airspeed": self.airspeed,
            "vx": self.vx, "vy": self.vy, "vz": self.vz,
            "voltage": self.voltage, "current": self.current,
            "battery_pct": self.battery_pct,
            "rssi_percent": self.rssi_percent,
            "armed": self.armed, "flight_mode": self.flight_mode,
            "mean_temp": self.mean_temp, "mean_rh": self.mean_rh,
            "pressure": self.pressure,
            "wind_speed": self.wind_speed,
            "wind_direction": self.wind_direction,
            "vertical_wind": self.vertical_wind,
            "throttle": self.throttle,
            "time_since_boot": self.time_since_boot,
        }
